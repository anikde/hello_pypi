
# main.py
def hello():
    print("Hello from pip package")