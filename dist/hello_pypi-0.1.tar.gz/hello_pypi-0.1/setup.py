from setuptools import setup, find_packages

setup(
    name="hello_pypi",
    version="0.1",
    packages=find_packages(),
    install_requires=[

    ],
)